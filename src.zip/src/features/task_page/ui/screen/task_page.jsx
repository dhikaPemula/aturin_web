import Header from "../../../../core/widgets/header/header.jsx";

function Task() {
  return (
    <>
        <div style={{ padding: '20px' }}>
            <h1>Welcome to the Task Page</h1>
            <p>This is the main content area for the task page.</p>
        </div>
    </>
  );
}
export default Task;